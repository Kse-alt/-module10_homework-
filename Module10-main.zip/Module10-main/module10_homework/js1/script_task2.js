let x;
typeof x;
if (typeof (x) === Number){
console.log ('x - это число');
}
else if (typeof (x) === String) {
    console.log ('x - это строка');
}
else if (typeof (x) === Boolean ) {
    console.log ( 'x - это логический тип');
}
else {
    console.log ('Тип х не определен');
}
