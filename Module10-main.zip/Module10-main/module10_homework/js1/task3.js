let str = 'hello';
let reversestr = str.split ('').reverse().join('');
console.log (reversestr);