let arr = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'];
console.log(arr.length);

for (let i = 0; i < arr.length; i++){
    console.log(arr[i]);
}