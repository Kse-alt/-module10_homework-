let x = Math.random ()*100;
x = Math.ceil (x);
console.log (x);